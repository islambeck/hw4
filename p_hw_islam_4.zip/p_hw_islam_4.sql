SELECT * FROM check_employee_department;


INSERT INTO check_employee_department(name,address)
VALUES
    ('sales_department', 'Bishkek'),
    ('IT_department', 'Bishkek'),
    ('accounting_department', 'Bishkek'),
    ('customer_service_department', 'Talas');


SELECT * FROM check_employee_positions;

INSERT INTO check_employee_positions (name)
VALUES
    ('Active Sales Manager'),
    ('Direct Sales Manager'),
    ('Web Designer'),
    ('IT recruiter'),
    ('Accountant'),
    ('Chief Accountant'),
    ('Account Manager'),
    ('Head of Sales Department');
	


INSERT INTO check_employee_employee (fullname, birth_date, salary, receipt_date, department_id, position_id)
VALUES
    ('Иванов Иван Иванович', '1990-01-01', 60000, '2015-01-15', 3, 1),
    ('Асанов Асан Асанович', '1985-03-15', 70000, '2014-02-20', 2, 7),
    ('Калысов Калыс Айбекович', '1995-05-10', 55000, '2009-03-10', 3, 5),
    ('Фархатов Атай Фархатович', '1992-07-20', 48000, '2008-04-05', 1, 1),
    
	('Сергеев Иван Сергеевич', '19997-01-01', 51000, '2015-01-15', 1, 5),
    ('Асанов Бакыт Асанович', '1985-03-15', 78000, '2014-02-20', 4, 6),
    ('Айбеков Калыс Айбекович', '1995-05-10', 57000, '2009-03-10', 3, 8),
    ('Бакытов Султан Фархатович', '1991-07-20', 40000, '2008-04-05', 2, 6),
	 
	 
	('Омурбеков Сыймык Бакытович', '1985-01-01', 61000, '2015-01-15', 3, 5),
    ('Асанов Санжар Асанович', '1987-03-15', 75000, '2014-02-20', 2, 6),
    ('Исламов Нурбек Айбекович', '1980-05-10', 58000, '2009-03-10', 4, 6),
    ('Бакытов Мирлан Фархатович', '1990-07-20', 40000, '2008-04-05', 3, 3),
	 
	 
	 
	 
	('Жапаров Бакыт Айбекович', '1997-01-01', 60000, '2023-05-15', 1, 3),
    ('Бердиев Нурсултан Асанович', '1990-03-15', 70000, '2023-06-20', 2, 7),
    ('Калыбеков Дастан Калыбекович', '1991-05-10', 55000, '2023-07-10', 3, 6),
    ('Адилов Мирлан Адилович', '1990-07-20', 48000, '2023-04-05', 4, 7);
	 
	 
SELECT * FROM check_employee_employee;
	----получите данные всех сотрудников, отсортированных по зарплате по убыванию 
	 
SELECT * FROM check_employee_employee ORDER BY salary DESC;

-- Получите данные всех сотрудников, отсортированных по дате рождения по убыванию и по дате начала работы по возрастанию
SELECT * FROM check_employee_employee ORDER BY birth_date DESC, receipt_date;

SELECT * FROM check_employee_employee
WHERE salary
BETWEEN 20000  AND 50000

SELECT * FROM check_employee_employee WHERE department_id = 2 ORDER BY fullname;

 
SELECT name AS department_name, COUNT(e.id) AS employee_count
FROM check_employee_department c
LEFT JOIN check_employee_employee AS e ON c.id = e.department_id
GROUP BY c.name
ORDER BY employee_count ASC;


-- SELECT check_employee_department.name AS department_name, COUNT(check_employee_employee.id) AS employee_count
-- FROM check_employee_department
-- LEFT JOIN check_employee_employee ON check_employee_department.id = check_employee_employee.department_id
-- GROUP BY check_employee_department.name
-- ORDER BY employee_count ASC;

SELECT name AS department_name, AVG(e.salary) AS average_salary
FROM check_employee_department c
LEFT JOIN check_employee_employee e ON c.id = e.department_id
GROUP BY c.name;

SELECT name AS department_name, COUNT(e.id) AS employee_count
FROM check_employee_department c
LEFT JOIN check_employee_employee e ON c.id = e.department_id
GROUP BY c.name
ORDER BY employee_count ASC;

SELECT
    e.fullname AS employee_name,
    d.name AS department_name,
    p.name AS position_name
FROM
    check_employee_employee AS e
LEFT JOIN
    check_employee_department AS d ON e.department_id = d.id
LEFT JOIN
    check_employee_positions AS p ON e.position_id = p.id;


SELECT check_employee_employee.fullname, check_employee_department.name AS department_name, check_employee_positions.name AS position_name
FROM check_employee_employee
LEFT JOIN check_employee_department 
ON
check_employee_employee.department_id = check_employee_department.id
LEFT JOIN check_employee_positions 
ON
check_employee_employee.position_id = check_employee_positions.id;



ALTER TABLE check_employee_employee
ADD bonus numeric;  -- Создаем столбец "bonus" с числовым типом данных

UPDATE check_employee_employee
SET bonus = 
  CASE 
    WHEN (DATE_PART('year', current_date) - DATE_PART('year', receipt_date)) >= 5 AND department_id = 2 THEN salary * 0.08
    WHEN (DATE_PART('year', current_date) - DATE_PART('year', receipt_date)) >= 5 THEN salary * 0.05
    ELSE 0
  END;

ALTER TABLE check_employee_employee
ADD vacancy date;  -- Создаем столбец "vacancy" с типом данных дата

UPDATE check_employee_employee
SET vacancy = receipt_date + INTERVAL '1 year' * 5; -- Отпуск после 5 лет работы








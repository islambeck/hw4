from django.db import models

from django.db import models

from django.db import models

from django.db import models
from django.core.validators import MinValueValidator
from django.utils import timezone
from datetime import date


class Department(models.Model):
    name = models.CharField(max_length=50)
    address = models.CharField(max_length=100)


class Positions(models.Model):
    name = models.CharField(max_length=50)


class Employee(models.Model):
    fullname = models.CharField(max_length=100)
    birth_date = models.DateField(validators=[MinValueValidator(limit_value=25)])
    salary = models.FloatField()
    receipt_date = models.DateField(default=timezone.now() + timezone.timedelta(days=1))
    department = models.ForeignKey(Department, on_delete=models.CASCADE)
    position = models.ForeignKey(Positions, on_delete=models.CASCADE)



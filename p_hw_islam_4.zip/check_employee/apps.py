from django.apps import AppConfig


class CheckEmployeeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'check_employee'
